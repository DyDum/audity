# CIS Benchmarks Management

Application web pour gestion CIS Benchmarks

## Features

- ✅ Authentification (local, Azure AD, LDAP)
- ✅ MFA support
- ✅ Gestion serveurs
- ✅ Scans CIS
- ✅ Exécution SSH

## Quick Start

Voir QUICKSTART.md
